#!/bin/bash

grep "error" /var/log/syslog|awk '{print $1, ":", substr($0, index($0,$6))}'

echo "Total no. of errors $(grep -c "error" /var/log/syslog) "
