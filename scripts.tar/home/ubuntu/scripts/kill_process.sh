#!/bin/bash

echo "Please enter process name"
read process_name


prID=$(ps -aux|grep $process_name|grep -v grep|head -n 1|awk '{print $2}')
 
#echo "$prID"
kill -9 "$prID"
echo "$process_name has been terminated"
