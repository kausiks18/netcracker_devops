#!/bin/bash

echo "Please enter your name for scripts"

read user_name 

echo "Hello,$user_name !Welcome to World!"
