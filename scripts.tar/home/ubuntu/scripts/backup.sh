#!/bin/bash


if [ -d "/home/ubuntu/backup" ]; then
	echo "Directory  exists"
   cp /home/ubuntu/documents/* /home/ubuntu/backup

else
	echo "Directory not exists"
mkdir /home/ubuntu/backup
echo "Backup directory has been created,please run scripts again"
fi
