#!/bin/bash
echo "Welcome to backup files scripts"

DATE=$(date +%F)_bkp

SRC="/home/ubuntu/documents"
DEST="/home/ubuntu/backup"

if [ -d "$DEST" ]; then
    echo -e "Directory exists\n copying file"

for file in "$SRC"/*;do
   if [ -f "$file" ]; then
	   filename=$(basename "$file")
           extension="${filename##*.}"
           name="${filename%.*}"
	   cp "$file" "$DEST/${name}_$DATE.${extension}"
    fi

   done
   echo "back up completed with date suffix"

else
	echo "Directory not exists"
	mkdir -p "$DEST"

	echo "Backup directory has been created.Please run the script again"

fi

